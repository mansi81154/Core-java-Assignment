/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Loops;

/**
 *
 * @author mansi
 */
public class Loop13 {
    public static void main(String as[])
    {
        int num1=10,num2=20,num3=30;
        if(num1>num2 && num1>num2)
        {
              System.out.println("10 is large");
        }
        else if(num2>num1 && num2>num3)
        {
            System.out.println("20 is large");
        }
        else
        {
           System.out.println("30 is large");
         }
   }
    
}
