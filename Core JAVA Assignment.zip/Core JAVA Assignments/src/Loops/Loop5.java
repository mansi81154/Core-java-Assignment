/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Loops;

/**
 *
 * @author mansi
 */
public class Loop5 {
  public void Larger(int num1,int num2,int num3)
   {
       if(num1>num2&&num1>num3)
       {
          System.out.println("number1 is large");
       }
       else if(num2>num1&&num2>num3)
       {
          System.out.println("number 2 is large");
       }
       else if(num3>num1&&num3>num1)
       {
         System.out.println("number3 is large");
       }
    }
   public static void main(String as[])
   {
     Loop5 obj=new Loop5();
     obj.Larger(10,30,50);
    }  
}
