/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Loops;

/**
 *
 * @author mansi
 */
public class Loop1 {
     public static void main(String as[])
   {
     for(int i=1;i<=10;i++)
     {
        System.out.println("Bright IT Career");
     }
  }
}
