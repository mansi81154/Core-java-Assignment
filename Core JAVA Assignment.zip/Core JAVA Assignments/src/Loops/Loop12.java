/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Loops;

/**
 *
 * @author mansi
 */
public class Loop12 {
   public static void main(String as[])
{
    char gender='f';

    switch(gender)
    {
        case 'M':
        case 'm':
            System.out.println("Male");
            break;
        case 'F':
        case 'f':
            System.out.println("Female");
            break;
        default:
            System.out.println("Unspecified Gender\n");
    }

}  
}
