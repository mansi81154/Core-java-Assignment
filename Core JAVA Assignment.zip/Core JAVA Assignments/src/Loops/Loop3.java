/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Loops;

/**
 *
 * @author mansi
 */
public class Loop3 {
    public static void main(String as[])
   {  int num1=20,num2=20,num3=40;
      if(num1==num2)
      {
         System.out.println("both numbers are equal");
      }
      if(num1!=num3)
      {
       System.out.println("both numbers are not equal");
      }
   }
}
