/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Loops;

/**
 *
 * @author mansi
 */
public class Loop6 {
    public void even()
   {
      int i=10;
      while(i<100)
      {
        if(i%2==0)
        {
           System.out.println(i);
        }
        i++;
     }
  }
  public static void main(String as[])
  {
      Loop6 obj=new Loop6();
      obj.even();
  }
}
