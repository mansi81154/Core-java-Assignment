/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Strings;

/**
 *
 * @author mansi
 */
public class String14 {
     public static void main(String as[])
   {
      String str1="hello";
      String str2="WORLD";
      System.out.println(str1.toUpperCase());
      System.out.println(str2.toLowerCase()); 
  }
}
