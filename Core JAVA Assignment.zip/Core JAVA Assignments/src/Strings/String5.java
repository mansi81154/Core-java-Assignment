/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Strings;

/**
 *
 * @author mansi
 */
public class String5 {
     public static void main(String[] args) {
    String myStr = "Hello planet earth, you are a great planet.";
    System.out.println("Index of planet is: "+myStr.indexOf("planet"));
  }
}
