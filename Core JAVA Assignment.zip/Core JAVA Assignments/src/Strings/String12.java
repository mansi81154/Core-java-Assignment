/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Strings;

/**
 *
 * @author mansi
 */
public class String12 {
    public static void main(String args[]){  
int i=200;  
String s=String.valueOf(i);  
System.out.println(i+100);//300 because + is binary plus operator  
System.out.println(s+100);//200100 because + is string concatenation operator  
}
}
