/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Strings;

/**
 *
 * @author mansi
 */
public class String8 {
     public static void main(String[] args) {
  String str1 = "This is a test string";
  String str2 ="I love India";
   System.out.println(str1.substring(0, 4).equalsIgnoreCase("this"));

   if(str1.compareTo(str2) == 0){
      System.out.println("str1 is equal to str2");
    }else{
      System.out.println("str1 is not equal to str2");
    }
   
   System.out.println(str1.startsWith("test", 10));
   System.out.println(str1.endsWith("test"));
  }
}
