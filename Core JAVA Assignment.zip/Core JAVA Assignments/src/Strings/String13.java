/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Strings;

/**
 *
 * @author mansi
 */
public class String13 {
  public static void main(String args[])
  {
    int a = 1234;
    int b = -1234;
    String str1 = Integer.toString(a);
    String str2 = Integer.toString(b);
    System.out.println("String str1 = " + str1);
    System.out.println("String str2 = " + str2);
  }  
}
