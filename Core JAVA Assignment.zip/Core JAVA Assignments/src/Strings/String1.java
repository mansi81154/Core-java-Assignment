/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Strings;

/**
 *
 * @author mansi
 */
public class String1 {
    public static void main(String as[])
   {
   String str="Hello!";
   System.out.println(str);
   String str1= new String("Hello!");
   System.out.println(str);
   char ch[]={ 'H','e','l','l','o','!',};
   String str2=new String(ch);
   System.out.println(ch);
  }

}
