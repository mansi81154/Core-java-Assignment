/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Strings;

/**
 *
 * @author mansi
 */
public class String4 {
 public static void main(String args[]) {

      String str = "Welcome to Tutorialspoint";
      String sub = str.substring(10, 25);
      System.out.println(sub);
   }   
}
