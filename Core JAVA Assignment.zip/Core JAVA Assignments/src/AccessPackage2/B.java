/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package AccessPackage2;
import AccessPackage1.*;  
/**
 *
 * @author mansi
 */
public class B extends A{
    public static void main(String args[]){  
   B obj = new B();  
   obj.msg();  
  }  
}

// You cant access procted fields and method outside package or different package ..