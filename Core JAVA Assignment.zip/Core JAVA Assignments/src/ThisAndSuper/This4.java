/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ThisAndSuper;

/**
 *
 * @author mansi
 */
public class This4 {
  int x;

  // Constructor with a parameter
  public This4(int x) {
    this.x = x;
  }

  // Call the constructor
  public static void main(String[] args) {
    This4 myObj = new This4(5);
    System.out.println("Value of x = " + myObj.x);
  }  
}
