/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ThisAndSuper;

/**
 *
 * @author mansi
 */
class Person
{
    void message()
    {
        System.out.println("This is person class");
    }
}
  
/* Subclass Student */
class Student extends Person
{
    void message()
    {
        System.out.println("This is student class");
        
    }
  
    // Note that display() is only in Student class
    void display()
    {
        // will invoke or call current class message() method
        this.message();
        
        // will invoke or call parent class message() method
        super.message();
    }
}

public class This6 {
    public static void main(String args[])
    {
        Student s = new Student();
  
        // calling display() of Student
        s.display();
    
    }
}
