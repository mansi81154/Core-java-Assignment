/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ThisAndSuper;

/**
 *
 * @author mansi
 */
class Animal{  
Animal(){System.out.println("animal is created");}  
}  
class Dog extends Animal{  
Dog(){  
super();  
System.out.println("dog is created");  
}  
}  
public class This5 {
    public static void main(String args[]){  
Dog d=new Dog();  
}
}
