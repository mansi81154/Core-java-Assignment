/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ThisAndSuper;

/**
 *
 * @author mansi
 */
public class This1 {
     This1()
    {
        this(10);
        System.out.println("Flow comes back from " + 
                           "RR class's 1 arg const");
    }
  
    This1(int a)
    {
        System.out.println("RR class's 1 arg const");
    }
    public static void main(String[] args)
    {
        new This1();
        System.out.println("Inside Main");
    }
}
