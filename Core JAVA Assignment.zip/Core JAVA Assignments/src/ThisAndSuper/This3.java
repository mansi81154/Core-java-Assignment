/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ThisAndSuper;

/**
 *
 * @author mansi
 */

class A{  
A()
{
  
  System.out.println("hello a");
}  
A(int x){  
this();  
  
}  
}  
public class This3 {
   public static void main(String args[]){  
A a=new A();  
}
}
