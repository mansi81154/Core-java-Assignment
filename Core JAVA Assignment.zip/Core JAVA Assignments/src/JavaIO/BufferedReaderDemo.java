/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package JavaIO;
import java.io.*;
/**
 *
 * @author mansi
 */
public class BufferedReaderDemo {
    public static void main(String as[]) throws Exception
   {
      FileReader fr=new FileReader("C:/users/mansi/desktop/File1.txt");
      BufferedReader br=new BufferedReader(fr);
      String line=br.readLine();
      while(line!=null)
      {
         System.out.println(line);
         line=br.readLine();
      }
        br.close();
   }
}
