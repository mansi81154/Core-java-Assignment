/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package JavaIO;
import java.io.*;
/**
 *
 * @author mansi
 */
public class BufferedWriterDemo {
    public static void main(String as[]) throws Exception
   {
       FileWriter fw=new FileWriter("C:/users/mansi/desktop/File2.txt");
       BufferedWriter bw=new BufferedWriter(fw);
       bw.write(100);
       bw.newLine();
       char[] ch1={'a','b','c','d','e'};
       bw.write(ch1);
       bw.newLine();
       bw.write("BufferedWriter");
       bw.newLine();
       bw.write("Demo");
       bw.flush();
       bw.close();
       System.out.println("Successfully wrote on File..");
   }
}
