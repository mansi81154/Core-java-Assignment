/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package JavaIO;
import java.io.*;
/**
 *
 * @author mansi
 */
public class FileWriterDemo {
    public static void main(String as[]) throws IOException
   {
      FileWriter fw=new FileWriter("C:/users/mansi/desktop/File2.txt");
      fw.write(100);
      fw.write("\nThis is added by FileWriter");
      char[] ch={'a','b','c'};
      fw.write(ch);
      fw.flush();
      fw.close();
      System.out.println("Successfully wrote on File..");
   }
}
