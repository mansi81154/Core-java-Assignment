/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package JavaIO;
import java.io.BufferedOutputStream;
import java.io.FileOutputStream;
/**
 *
 * @author mansi
 */
public class BufferOutputEg {
    
  public static void main(String[] args) throws Exception {
    BufferedOutputStream bufferedOutput = new BufferedOutputStream(new FileOutputStream("C:/Users/mansi/desktop/File2.txt"));
    bufferedOutput.write("This is the use of BufferedOutputStream".getBytes());
    bufferedOutput.write("\n".getBytes());

    bufferedOutput.write(65);
    bufferedOutput.close();
    System.out.println("Successfully wrote on file.");
  }
}
