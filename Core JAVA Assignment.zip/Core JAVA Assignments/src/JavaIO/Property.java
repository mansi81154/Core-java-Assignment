/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package JavaIO;
import java.util.*;  
import java.io.*;
/**
 *
 * @author mansi
 */
public class Property {
    public static void main(String[] args)throws Exception{  
    FileReader reader=new FileReader("C:/users/mansi/desktop/db.properties");  
      
    Properties p=new Properties();  
    p.load(reader);  
      
    System.out.println(p.getProperty("user"));  
    System.out.println(p.getProperty("password"));  
}  
}
