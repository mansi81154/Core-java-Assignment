/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package JavaIO;
import java.io.FileWriter;
import java.io.IOException;
/**
 *
 * @author mansi
 */
public class FileWrite {
    public static void main(String as[])
    {
    try
    {
            FileWriter f=new FileWriter("c:\\users\\mansi\\desktop\\File2.txt");
            f.write("MY NAME IS MANSI SAXENA,Currently pursuing MCA.");
            f.close();
            System.out.println("Successfully wrote in file.");
         
     }
    catch(IOException e)
    {
       System.out.println("error occured");   
    }
  }
}
