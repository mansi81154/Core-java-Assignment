/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package AbstractClasses;

/**
 *
 * @author mansi
 */
abstract class Animal1
{
   abstract void sound();
   public void CatSound()
   {
     System.out.println("Cat Sound is: Meow");
   }
}
class Abstract4 extends Animal1
{
   void sound()
   {
      System.out.println("Woof");
      
   }
   public static void main(String as[])
   {
      Abstract4 obj=new Abstract4();
      obj.CatSound();
   }
}
