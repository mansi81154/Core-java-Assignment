/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package AccessModifiers;

/**
 *
 * @author mansi
 */
 class AcceesField
{
    public int var1=10;
    public void display()
    {
        System.out.println("This is public method and value of public variable is: "+var1);
    }
}
 public class Access4 {
     public static void main(String args[]){  
   AcceesField obj = new AcceesField();  
   obj.display();  
  }  
}
