/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package AccessModifiers;
// Outside package protected fields or methods we can't access..
/**
 *
 * @author mansi
 */
public class Access3 {
   
 public static void main(String as[])
   {
      AccessClass obj=new AccessClass();
      obj.msg();
      System.out.println("This is protected variable value: "+obj.num);
   }
}
// Access the field in same package
class AccessClass
{
    protected int num=10;
    protected void msg()
    {
        System.out.println("This is protected method");
    }
}
