/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package AccessModifiers;

/**
 *
 * @author mansi
 */
public class Access1 {
     private String var1="Hello";
  private String var2="World";
  
  //private method
   
  private void Multi()
  {
     System.out.println(var1+var2);
  }
//}
 // class B extends Access1//We can't access Private members in subclass..
// {
  public static void main(String as[])
  {
     Access1 obj=new Access1();
     obj.Multi();
  } 
}
