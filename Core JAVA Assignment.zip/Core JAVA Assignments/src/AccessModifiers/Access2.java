/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package AccessModifiers;

/**
 *
 * @author mansi
 */
public class Access2 extends Access{
  public static void main(String as[]){
      Access2 obj=new Access2();
      obj.display();
      System.out.println("This is default field value: "+obj.var1);
  }
  
}
class Access 
{
    int var1=10;
    void display()
    {
       System.out.println("This is default method"); 
    }
}
