/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package JavaBasics;

/**
 *
 * @author mansi
 */
public class Basic4 {
    public static void main(String as[])
  {
  int i=10;
  boolean value=true;
  char c='a';
  float f=1.6f;
  double d=1.334567;
  System.out.println("Integer value:"+i);
  System.out.println("Boolean value:"+value);
  System.out.println("Char value:"+c);
  System.out.println("Float value:"+f);
  System.out.println("Double value:"+d);
  }
}
