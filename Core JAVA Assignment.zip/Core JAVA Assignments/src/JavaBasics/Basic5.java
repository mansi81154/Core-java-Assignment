/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package JavaBasics;

/**
 *
 * @author mansi
 */
public class Basic5 {
    static int num1=10; //This is global variable we can access this variable entire program..
  static int num2=20;
  
  public void display()
  {  
      //Here num1,num2 are local variable so its value will only active within the method..
      int num1=30;
      int num2=40;
     System.out.println("The value of num1 inside method is:"+num1);
     System.out.println("The value of num2 inside method is:"+num2);
  } 
  public static void main(String as[])
  {
  Basic5 obj=new Basic5();
  obj.display();
  System.out.println("The value of num1 outside the method is:"+num1);
  System.out.println("The value of num2 outside the method is:"+num2);  
 }
}
