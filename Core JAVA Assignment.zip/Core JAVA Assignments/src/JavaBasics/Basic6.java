/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package JavaBasics;

/**
 *
 * @author mansi
 */
public class Basic6 {
   public void display()
  {
    System.out.println("My name is Mansi Saxena");
  }
 public static void main(String as[])
 {
   Basic6 obj=new Basic6();
   obj.display();
 } 
}
