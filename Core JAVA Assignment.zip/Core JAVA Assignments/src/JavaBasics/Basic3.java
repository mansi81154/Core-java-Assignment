/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package JavaBasics;

/**
 *
 * @author mansi
 */
public class Basic3 {
    /** The Multi() method returns multiplication of given numbers.*/ 
  public void Multi(int num1,int num2) //this is the method of multiply two numbers..
  {
     int multi=num1*num2;
     System.out.println("Multiplication of two numbers is:"+multi);
  }
  /** The sum() method returns addition of given numbers.*/

  public void sum(int num1,int num2) //this is the method of adding two numbers..
  {
     int sum=num1+num2;
     System.out.println("Sum of two numbers is:"+sum);
  }
 
  /*
  This is the main methodd..
  where we can create the object of the class and call the method.
  */
  public static void main(String as[])
  {
     Basic3 obj=new Basic3();
     obj.Multi(10,5);
     obj.sum(10,20);
  }
}
