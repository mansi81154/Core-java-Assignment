/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Static;

/**
 *
 * @author mansi
 */
public class Static4 {
    void instance() //instance method
    {
         System.out.println("This is instance method..");
    }

   public static void main(String as[])
   {
      Static4 obj=new Static4();
      obj.instance();
  }
}
