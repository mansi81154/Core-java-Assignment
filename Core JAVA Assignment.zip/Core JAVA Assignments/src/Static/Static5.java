/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Static;

/**
 *
 * @author mansi
 */

public class Static5
{
  public static void main(String as[])
  {
    Static obj=new Static();
    obj.display(); 
  }   
}
class Static
{
   static void staticMethod() //static method
   {
     System.out.println("This is static method..");
   }
 
  void display()  //instance method
  {
   staticMethod();
  }  
}