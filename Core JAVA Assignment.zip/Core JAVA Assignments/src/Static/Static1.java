/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Static;

/**
 *
 * @author mansi
 */
public class Static1 {
    static int var1=10,var2=2; //static variables
   int var3=30,var4=40;       //instance variables
   public static int Sum()   //static method
   {
      return var1+var2;
   }
   public static int Diff()  //static method
   {
      return var1-var2;
   }
   public void Multi()      //instance method
   {
      System.out.println("In First Instance Method,Multiplication is: "+(var3*var4));
   }
   public void Div()      //instance method
   {
      System.out.println("In Second Instance Method,Division is: "+(var4/var3));
   }
   public static void main(String as[])
   {
   System.out.println("In First static method,Sum of " +var1+ " & " +var2+ " is: "+Sum());
   System.out.println("In Second static method,Difference of " +var1+ " & " +var2+ " is: " +Diff());
   Static1 obj=new Static1();
   obj.Multi();
   obj.Div();
   }
}
