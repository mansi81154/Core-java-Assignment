/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Interfaces;

/**
 *
 * @author mansi
 */
interface intfA
{
    void geekName();
}
  
interface intfB extends intfA
{
    void geekInstitute();
}
  
// class implements both interfaces and provides
// implementation to the method.
class Sample implements intfB
{
   
    public void geekName()
    {
        System.out.println("Mansi");
    }
  
    
    public void geekInstitute()
    {
        System.out.println("JIIT");
    }
  
    public static void main (String[] args)
    {
        Sample ob1 = new Sample();
  
        // calling the method implemented
        // within the class.
        ob1.geekName();
        ob1.geekInstitute();
    }
}