/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Interfaces;

/**
 *
 * @author mansi
 */
interface Interface10
{
   /*we cant use private and protected modifier in interfaces.
    private int var1=10;  
   protected String var2="Hello";*/
   public float var3=1.2f;
}

