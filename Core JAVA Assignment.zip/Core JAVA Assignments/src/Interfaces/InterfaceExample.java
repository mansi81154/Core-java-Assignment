/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Interfaces;

/**
 *
 * @author mansi
 */
interface Interface8{
   public int num = 100;
   public void display();
}
 class InterfaceExample implements Interface8{
   public  int num = 10000;
   public void display() {
      System.out.println("This is the implementation of the display method");
   }
   public void show() {
      System.out.println("This is the implementation of the show method");
   }
   public static void main(String args[]) {
      InterfaceExample obj = new InterfaceExample();
      System.out.println("Value of num of the interface "+Interface8.num);
      System.out.println("Value of num of the class "+obj.num);
   }
}
