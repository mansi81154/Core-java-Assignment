/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Interfaces;

/**
 *
 * @author mansi
 */
interface Interf
{
   void m1();
}
 class ServiceProvider implements Interf
{
  public void m1()
  {
     System.out.println("This is child class and this method is implemented..");
  }
  public static void main(String as[])
  {
    ServiceProvider obj=new ServiceProvider();
    obj.m1();
  }
}