/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Interfaces;

/**
 *
 * @author mansi
 */
interface Vehicle {

    void cleanVehicle();

    /* This method shows the error because abstract methods doesn't have body 
    void startVehicle() {
        System.out.println("Vehicle is starting");
    }*/
}


public class Car implements Vehicle {
    
    public void cleanVehicle() {
        System.out.println("Cleaning the vehicle");
    }

    public static void main(String args[]){
        Car car = new Car();
        car.cleanVehicle();
        
       /* Above i comment this method thats why it will show an error message..
               car.startVehicle();
       */
    }
}
