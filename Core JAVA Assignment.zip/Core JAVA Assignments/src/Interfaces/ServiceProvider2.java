/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Interfaces;

/**
 *
 * @author mansi
 */
interface Interface // Compile time error because child class must implement the parent class methods..
{
    void m1();
    void m2();
}
 class ServiceProvider2 implements Interf
{
  public void m1()
  {
     System.out.println("This is child class and this method is implemented..");
  }
  public static void main(String as[])
  {
    ServiceProvider2 obj=new ServiceProvider2();
    obj.m1();
  }
}
