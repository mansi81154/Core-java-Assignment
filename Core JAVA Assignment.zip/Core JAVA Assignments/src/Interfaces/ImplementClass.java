/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Interfaces;

/**
 *
 * @author mansi
 */
interface Interface1
{
   void m1();
}
interface Interface2
{
  void m2();
}
class ImplementedClass implements Interface1,Interface2
{
   public void m1()
   {
     System.out.println("This is m1 method");
   }
   public void m2()
   {
     System.out.println("This is m2 method");
   }
   public static void main(String as[])
   {
     ImplementedClass obj=new ImplementedClass();
     obj.m1();
     obj.m2();
   }
}
