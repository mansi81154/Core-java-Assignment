/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Interfaces;

/**
 *
 * @author mansi
 */
interface InterfaceA
{
  void m1(int a);
}
interface InterfaceB
{
  void m1(int a);
}

class ChildClass implements InterfaceA,InterfaceB
{
  public void m1(int a)
  {
    System.out.println("The value of a is: "+a);
  }
  public static void main(String as[])
  {
    ChildClass obj=new ChildClass();
    obj.m1(10);
  }
}
