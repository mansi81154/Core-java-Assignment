/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Interfaces;

/**
 *
 * @author mansi
 */
/*    We cant use private access modifier for inteface
private interface Abc   
{  
    
    // Private method  
     public void greet();
   
    
}  
class interface9 implements Abc{  
     public void greet() {
    	System.out.println("This is private method"); 
    }  
    public static void main(String[] args) {  
    	interface9 d = new interface9();  
        d.greet();     
  
    }  
}
*/ 
// We can't create interface as private because it is not allowed
