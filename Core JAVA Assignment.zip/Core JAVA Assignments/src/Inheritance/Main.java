/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Inheritance;

/**
 *
 * @author mansi
 */
class A
{
  public void Sum()
  {
     int a=10,b=20;
     System.out.println("Sum is: "+(a+b));
  }
  public void Sub()
  {
    int a=5,b=5;
    System.out.println("Sum is: "+(a-b));
  }
  public void display()
  {
     System.out.println("This is Class A method");
  }
}
class B extends A
{
   public void Multi()
  {
     int a=10,b=20;
     System.out.println("Sum is: "+(a*b));
  }
  public void Div()
  {
    int a=5,b=5;
    System.out.println("Sum is: "+(a/b));
  }
  public void display()
  {
     System.out.println("This is Class B method");
  }
}
class C extends B
{
   public void Larger()
  {
     int a=10,b=20;
     if(a>b)
     System.out.println("a is large");
     else
     System.out.println("b is large");
  }
  public void evenOdd()
  {
    int a=5;
    if(a%2==0)
    System.out.println("no. is even");
    else
    System.out.println("no is odd");
  }

 public void display()
  {
     System.out.println("This is Class C method");
  }
 
} 
class Main
 {
   public static void main(String as[])
   {
    A obj1=new A();
    obj1.Sum();
    obj1.Sub();
    obj1.display();
    B obj2=new B();
    obj2.Multi();
    obj2.Div();
    obj2.display();
    C obj3=new C();
    obj3.Larger();
    obj3.evenOdd();
    obj3.display();
    System.out.println();
    A obj4=new B();
    A obj5=new C();
    obj4.display();
    obj5.display();
   }
 } 

 //  RunTime Polymorphism

class Poly1
{
  public void Sum(int a,int b)
  {
     
     System.out.println("Sum is: "+(a+b));
  }
  public void Sub(int a,int b)
  {
    
    System.out.println("Sum is: "+(a-b));
  }
  public void display(int a)
  {
     int b=10;
     int c=a+b;
     System.out.println("Inside First Class value of a: "+c);
  }
}
class Poly2 extends Poly1
{
   public void Multi(int a,int b)
  {
    
     System.out.println("Sum is: "+(a*b));
  }
  public void Div(int a,int b)
  {
    
    System.out.println("Sum is: "+(a/b));
  }
  public void display(int a)
  {
     int b=10;
     int c=b-a;
     System.out.println("Inside Second Class value of a: "+c);  
  }
}
class Poly3 extends Poly2
{
   public void Larger(int a,int b)
  {
     
     if(a>b)
     System.out.println("a is large");
     else
     System.out.println("b is large");
  }
  public void evenOdd(int a)
  {
    
    if(a%2==0)
    System.out.println("no. is even");
    else
    System.out.println("no is odd");
  }

 public void display(int a)
  {
    int b=5;
    int c=a*b;
    System.out.println("Inside Third Class value of a: "+c);
  }
 
}   

class Main2
 {
   public static void main(String as[])
   {
    Poly1 obj1=new Poly1();
    obj1.Sum(10,20);
    obj1.Sub(5,5);
    obj1.display(10);
    Poly2 obj2=new Poly2();
    obj2.Multi(10,20);
    obj2.Div(5,5);
    obj2.display(10);
    Poly3 obj3=new Poly3();
    obj3.Larger(10,20);
    obj3.evenOdd(5);
    obj3.display(10);
    System.out.println();
    Poly1 obj4=new Poly2();
    Poly1 obj5=new Poly3();
    obj4.display(10);
    obj5.display(10);
   }
 } 
