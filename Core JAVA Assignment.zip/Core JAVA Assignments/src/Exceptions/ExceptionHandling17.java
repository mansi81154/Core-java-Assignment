/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Exceptions;
import java.util.*;
/**
 *
 * @author mansi
 */
public class ExceptionHandling17 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Enter the input text : ");
        
            char c = scanner.nextLine().charAt(4);
            System.out.println("The character at index 4 is : "+c);
        
            //StringIndexOutOfBoundsException cannot be caught explicitly
         
      
    }
}
