/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Exceptions;

/**
 *
 * @author mansi
 */
public class ExceptionHandling10 {
    
	public static void main(String args[]) {
		try
		{
			Class.forName("This is ClassNotFound Exception");
		}
		catch (ClassNotFoundException ex)
		{
			ex.printStackTrace();
		}
	}
}
