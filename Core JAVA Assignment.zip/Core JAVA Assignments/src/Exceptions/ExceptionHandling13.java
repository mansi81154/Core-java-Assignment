/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Exceptions;
import java.util.*;
/**
 *
 * @author mansi
 */
public class ExceptionHandling13 {
    private Object obj;

	ExceptionHandling13()
	{

		class Arr {
		};

		obj = new Arr();
	}

	public static void main(String[] args)
		throws ClassNotFoundException, NoSuchFieldException
	{
		ExceptionHandling13  t = new ExceptionHandling13 ();

		// returns the Class object
		Class myClass = t.obj.getClass();

		String fieldName = "obj";

		try {
			// Get the field of myClass
			// using getField() method
			System.out.println(
				fieldName + " Field of myClass: "
				+ myClass.getField(fieldName));
		}
		catch (Exception e) {
			System.out.println(e);
		}
	}
}
