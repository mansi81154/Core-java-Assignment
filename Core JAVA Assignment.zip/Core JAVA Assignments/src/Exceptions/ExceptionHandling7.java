/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Exceptions;

/**
 *
 * @author mansi
 */
public class ExceptionHandling7 {
   public static void main(String args[]){  
  try{  
   int data=30/0;  
   System.out.println(data);  
  }  
  catch(NullPointerException e)
  {
     System.out.println(e);
  }  
  finally
  {
      System.out.println("finally block is always executed");}  
      System.out.println("rest of the code...");  
  }   
}
