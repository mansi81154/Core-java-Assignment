/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Exceptions;

/**
 *
 * @author mansi
 */
public class ExceptionHandling2 {
    public void ArithException(int a,int b)
   {
      System.out.println(a/b);
   }
 
   public static void main(String as[])
   {
      try
      {
      ExceptionHandling1 obj=new ExceptionHandling1();
      obj.ArithException(2,0);
      }
      catch(Exception e)
      {
        System.out.println("Exception Handled");
      }
   }
}
