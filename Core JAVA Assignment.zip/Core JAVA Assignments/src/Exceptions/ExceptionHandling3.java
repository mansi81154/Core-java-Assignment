/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Exceptions;
import java.io.*;
/**
 *
 * @author mansi
 */
  
class Test{  
 void method()throws IOException{  
  System.out.println("device operation performed");  
 }  
}  
public class ExceptionHandling3 {
  public static void main(String args[])throws IOException{//declare exception  
     Test m=new Test();  
     m.method();  
  
    System.out.println("normal flow...");  
  }    
}
