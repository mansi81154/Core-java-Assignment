/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Exceptions;

/**
 *
 * @author mansi
 */
public class ExceptionHandling16 {
    
    public static void main(String[] args) {  
         int a = Integer.parseInt(null); //throws Exception as     //the input string is of illegal format for parsing as it is null.  
    }  
}
