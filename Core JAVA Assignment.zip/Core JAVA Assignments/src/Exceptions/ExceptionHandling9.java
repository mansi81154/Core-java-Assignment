/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Exceptions;

/**
 *
 * @author mansi
 */
public class ExceptionHandling9 {
    public static void main(String[] args) {  
   String[] arr = {"Nia","Mayank","Maya","Shayara"};   
//Declaring 4 elements in the String array                                       
          
        for(int i=0;i<=arr.length;i++) {       
  
//Here, no element is present at the iteration number arr.length, i.e 4  
             System.out.println(arr[i]);      
//So it will throw ArrayIndexOutOfBoundException at iteration 4           
        }  
  
    }  
}
