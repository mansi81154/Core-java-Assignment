/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Exceptions;
import java.lang.reflect.Method;
/**
 *
 * @author mansi
 */
public class ExceptionHandling14 {
   public ExceptionHandling14()
  {
    Class c;
    try
    {
      c = Class.forName("java.lang.String");
      
        Class[] paramTypes = new Class[5];
       /* This line will generate an error
               Method m = c.getDeclaredMethod("fooMethod", paramTypes);
     */
      }
      catch (ClassNotFoundException e)
    {
      // deal with the exception here ...
      e.printStackTrace();
    }
   
    
  }

  public static void main(String[] args)
  {
    new ExceptionHandling14();
  }
 
}
