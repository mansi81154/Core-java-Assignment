/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Exceptions;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
/**
 *
 * @author mansi
 */
public class ExceptionHandling12 {
   public void checkFileNotFound()
    {
        try
        {
            FileInputStream in = new FileInputStream("input.txt");
            System.out.println("This is not printed");
        } 
        catch (FileNotFoundException fileNotFoundException)
        {
            fileNotFoundException.printStackTrace();
        }
    }
    public static void main(String[] args)
    {
        ExceptionHandling12 example = new ExceptionHandling12();
        example.checkFileNotFound();
    } 
}
