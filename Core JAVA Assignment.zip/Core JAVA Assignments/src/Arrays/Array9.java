/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Arrays;

/**
 *
 * @author mansi
 */
public class Array9 {
    static int [] arr = new int [] {1, 2, 3, 4, 5};
    public static void main(String[] args) 
    {  
        //Initialize array  
          
        System.out.println("Original array: ");  
        for (int i = 0; i < arr.length; i++) {  
            System.out.print(arr[i] + " ");  
        }  
        System.out.println();
        Array9 obj=new Array9();
        obj.reverse();
   }  
     public void reverse()
     {
        System.out.println("Array in reverse order: ");  
        //Loop through the array in reverse order  
        for (int i = arr.length-1; i >= 0; i--) {  
            System.out.print(arr[i] + " ");  
        }  
      } 
}
