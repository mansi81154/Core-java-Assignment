/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Arrays;
import java.util.Arrays; 
/**
 *
 * @author mansi
 */
public class Array16 {
    static int[] array_nums = {5, 7, 2, 4, 9};
 public static void main(String[] args)
 {
        
	System.out.println("Original Array: "+Arrays.toString(array_nums));
        Array16 obj=new Array16();
        obj.differ(); 
  }
    public void differ()
    {
        int max_val = array_nums[0];
	int min = array_nums[0];
	for(int i = 1; i < array_nums.length; i++)
	{
		if(array_nums[i] > max_val)
			max_val = array_nums[i];
                        
		else if(array_nums[i] < min)
			min = array_nums[i];
	}
        System.out.println("Smallest Value: "+min);
        System.out.println("Largest Value: "+max_val);
	System.out.println("Difference between the largest and smallest values of the said array: "+(max_val-min));	
 }
}
