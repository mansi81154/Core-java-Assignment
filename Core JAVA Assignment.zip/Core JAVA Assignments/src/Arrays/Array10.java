/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Arrays;

/**
 *
 * @author mansi
 */
public class Array10 {
    static int [] arr = new int [] {1, 2, 3, 4, 2, 7, 8, 8, 3};   
          
        
         public void dupli()
         { 
        
        System.out.println("Duplicate elements in given array: ");  
        //Searches for duplicate element  
        for(int i = 0; i < arr.length; i++) {  
            for(int j = i + 1; j < arr.length; j++) {  
                if(arr[i] == arr[j])  
                    System.out.println(arr[j]);  
            }  
        }  
    } 
   public static void main(String[] args) {
     System.out.println("Given array elements:");
    for(int i=0;i<arr.length;i++) 
    {
      
       System.out.println(arr[i]);
    }
  Array10 obj=new Array10();
  obj.dupli();
  } 
}
