/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Arrays;

/**
 *
 * @author mansi
 */
public class Array3 {
    int arr[]={1,2,3,4,5,6};
   int element=5;
   int index=-1;
   public void index()
   {
     for(int i=0;i<arr.length;i++)
     {
         if(arr[i]==element)
         {  index=i;
              
         }
     }
    System.out.println("Index of " +element+ " is:" +index);
   }
  public static void main(String as[])
  {
      Array3 obj=new Array3();
      obj.index();
  } 
}
