/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Arrays;

/**
 *
 * @author mansi
 */
public class Array2 {
    
    public static void main(String[] args) {
        double[] arr = {19, 12.89, 16.5, 200, 13.7};
        double sum = 0;

        for(int i=0; i<arr.length; i++)
        {
        	sum = sum + arr[i];
        }


        
        double average = sum / arr.length;
        
        
        System.out.format("The average is: %.3f", average);
    }
}
