/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Arrays;
import java.util.Arrays;
/**
 *
 * @author mansi
 */
public class Array5 {
  static int my_array[] = {25, 14, 56, 15, 36, 65, 77, 18, 29, 49};
   public void remove()
   {
      // Remove the second element (index->1, value->14) of the array
      int removeIndex = 2;

       for(int i = removeIndex; i < my_array.length -1; i++)
       {
           my_array[i] = my_array[i + 1];
        }
   
       System.out.println("After removing the second element: "+Arrays.toString(my_array));
    }
    public static void main(String[] args) {
       
       System.out.println("Original Array : "+Arrays.toString(my_array));
       Array5 obj=new Array5();
       obj.remove();
 }  
}
