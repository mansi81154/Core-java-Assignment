/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Arrays;

/**
 *
 * @author mansi
 */
public class Array1 {
    int arr[]={2,4,6,7,8};
         int sum=0;
    public void add()
    {
         
         for(int i=0;i<arr.length;i++)
         {
           sum=sum+arr[i];
           
         }System.out.println("Sum is: "+sum);
   }
   public static void main(String as[])
   {
      Array1 obj=new Array1();
      obj.add();
    }
}
