/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Arrays;

/**
 *
 * @author mansi
 */
public class Array11 {
    static int arr1[]={1,2,3,4,5,6,60};
   static int arr2[]={10,2,30,6,60,40};
   public static void main(String as[])
   {
       System.out.println("First Array Elements: ");
       for(int i=0;i<arr1.length;i++)
       {
           System.out.println(arr1[i]);
       }
     
      System.out.println("Second Array Elements: ");
       for(int i=0;i<arr2.length;i++)
       {
           System.out.println(arr2[i]);
       } 
      Array11 obj=new Array11();
      obj.match();    
   }
   public void match()
   {
       for(int i=0;i<arr1.length;i++)
       {
           for(int j=0;j<arr2.length;j++)
          {
            if(arr1[i]==arr2[j])
           {
              System.out.println("Common Element: "+arr1[i]);
           }
          
         }
       }
   }
}
