/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Arrays;

/**
 *
 * @author mansi
 */
public class Array15 {
   static int arr[]={12,20,35,45,51,67};
   public void EvenOdd()
   {
      
      for(int i=0;i<arr.length;i++)
      {
          if(arr[i]%2==0)
          {
             System.out.println(arr[i]+" is even");
           }
          else
          {
             System.out.println(arr[i]+" is odd");
          }
     }
    }
    public static void main(String as[])
    {   
        System.out.println("Array elements are:\n");
        for(int i=0;i<arr.length;i++)
        {
            System.out.print(arr[i]+"\t");
         }
        System.out.println("");
        Array15 obj=new Array15();
        obj.EvenOdd();
    } 
}
