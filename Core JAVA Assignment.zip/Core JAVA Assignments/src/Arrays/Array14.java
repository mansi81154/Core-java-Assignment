/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Arrays;

/**
 *
 * @author mansi
 */
public class Array14 {
          static int arr[] = { 14, 46, 47, 86, 92, 52, 48, 36, 66, 85 
};
		int largest = arr[0];
		int secondLargest = arr[0];
		
 
	public static void main(String[] args) {
 
		
		System.out.println("The given array is:" );
		for (int i = 0; i < arr.length; i++) {
			System.out.print(arr[i]+"\t");
		}
              Array14 obj=new Array14();
              obj.largest();
       }
      public void largest()
      {
		for (int i = 0; i < arr.length; i++) {
 
			if (arr[i] > largest) {
				secondLargest = largest;
				largest = arr[i];
 
			} else if (arr[i] > secondLargest) {
				secondLargest = arr[i];
 
			}
		}
 
		System.out.println("\nSecond largest number is:" + 
secondLargest);
 
	} 
}
