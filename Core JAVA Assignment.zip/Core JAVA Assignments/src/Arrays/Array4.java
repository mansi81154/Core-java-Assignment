/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Arrays;

/**
 *
 * @author mansi
 */
public class Array4 {
    public static boolean index(int arr[],int item)
   {
      for (int n : arr) {
         if (item == n) {
          return true;
         }
      }
         return false;
   }   
    
    public static void main(String as[])
    {
          int arr[] = {
            1789, 2035, 1899, 1456, 2013, 
            1458, 2458, 1254, 1472, 2365, 
            1456, 2265, 1457, 2021};
          Array4 obj=new Array4();
          System.out.println(index(arr,2013));
          System.out.println(index(arr,2029));
     } 
}
