/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Collections;
import java.util.HashMap;

/**
 *
 * @author mansi
 */
public class Collection2 {
    public static void main(String[] args)
	{
		// Create an empty hash map
		HashMap<Integer,String> map = new HashMap<Integer,String>();

		// Add elements to the map
		map.put(1,"vishal");
		map.put(2,"sachin");
		map.put(3,"vaibhav");
                map.put(4,"vaibhavi");
                map.put(5,"vishakha");
                map.put(6,"ishu");
		map.put(7,"ishan");
		map.put(8,"ishika");
                map.put(9,"vandana");
                map.put(10,"vibhu");

                System.out.println(map);

                //insert a key vale into map
                 map.put(11,"sachin");
     
                //fetch the value for key 10
                System.out.println("The Value of key 10 is: " + map.get(10));

               //Create clone of HashMap
               System.out.println("The cloned map look like this: " + map.clone());

               //cheking the key is present or not
               System.out.println("Is the key 'vibhu' present? " +map.containsKey("vibhu"));

              //checking the value is present or not
              System.out.println("Is the value 'World' present? " +map.containsValue("World"));
 
               // Checking for the emptiness of Map
               System.out.println("Is the map empty? " + map.isEmpty());

		// Print size and content
		System.out.println("Size of map is: "+map.size());
 
               //Print all keys
               System.out.println("Printing all keys...");
               for (Integer key: map.keySet()) 
               System.out.println(key);

              //Remove key-value
             String returned_value = (String)map.remove(10);
 
           // Verifying the returned value
           System.out.println("Returned value is: "+ returned_value+" removed");
        		
          //copy one hashmap into new hashmap
          HashMap<Integer, String> new_hash_map = new HashMap<Integer, String>();
          new_hash_map.putAll(map);
  
        // Displaying the final HashMap
        System.out.println("The new map looks like this: " + new_hash_map);
		
	}
}
