/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Collections;
import java.util.*;
/**
 *
 * @author mansi
 */
public class ArrayListExample {
  public static void main(String args[]){  
      ArrayList<String> alist=new ArrayList<String>();  
      alist.add("Steve");
      alist.add("Tim");
      alist.add("Lucy");
      alist.add("Pat");
      alist.add("Angela");
      alist.add("Tom");
      alist.add("Jenny");
      alist.add("Suri");
      alist.add("Jack");
      alist.add("Joy");
  
      //displaying elements
      System.out.println(alist);
  
      //Adding an element to ArrayList
       alist.add("Jimmy");
      System.out.println(alist);
     
      //Adding "Steve" at the fourth position
      alist.add(3, "Steve");
  
      //displaying elements
      System.out.println(alist);

      //remove element
      alist.remove("Steve");

     //displaying elements
      System.out.println(alist);

    //remove element from specified index
      alist.remove(2);

    //displaying elements
      System.out.println(alist);
  
    //updating element
    alist.set(0, "Jenifer");

    //displaying elements
      System.out.println(alist);

    //iterating the ArrayList
       for(String str:alist)  
        System.out.println(str);   
      
     //Get an element by index
     System.out.println("Getting element by index: "+alist.get(2));
   
     //Find out the size
     System.out.println("Size of this ArrayList: "+alist.size());
 
     //Check element is present or not
      System.out.println("Element Present: "+alist.contains("Jimmy"));

      //Remove all element from ArrayList
      alist.clear(); 
     System.out.println("After clear ArrayList: "+alist); 
   }    
}
