/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Constructors;

/**
 *
 * @author mansi
 */

class Parentclass
{
   //no-arg constructor
   Parentclass(){
	System.out.println("no-arg constructor of parent class");
   }
   //arg or parameterized constructor
   Parentclass(String str){
	System.out.println("parameterized constructor of parent class");
   }
}
public class Constructor2 extends Parentclass {
   Constructor2(){
       /* super() must be added to the first statement of 
constructor 
	* otherwise you will get a compilation error. Another 
important 
	* point to note is that when we explicitly use super in 
constructor
	* the compiler doesn't invoke the parent constructor 
automatically.
	*/
	super("Hahaha");
	System.out.println("Constructor of child class");

   }
  
   public static void main(String args[]){		
	Constructor2 obj= new Constructor2();
	//obj.display();	 
   } 
}
