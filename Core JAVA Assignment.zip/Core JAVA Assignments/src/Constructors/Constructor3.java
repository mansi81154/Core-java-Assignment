/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Constructors;

/**
 *
 * @author mansi
 */

class Constructor
{
   private Constructor()
   {
      System.out.println("This is private constructor");
   }
   protected Constructor(int a)
   {
     System.out.println("This is protected constructor");
   }
   public Constructor(int a,int b)
   {
     System.out.println("This is public constructor");
   }
}
public class Constructor3 extends Constructor{
    Constructor3()
   {
     super(100);
     
   }
  Constructor3(int a)
   {
     super(100,100);
     
   }
   public static void main(String as[])
   {
   Constructor3 obj=new Constructor3();
   Constructor3 obj2=new Constructor3(10);
   }
}
