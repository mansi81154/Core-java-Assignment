/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Constructors;

/**
 *
 * @author mansi
 */
public class Constructor1 {
   public static void main(String as[])
   {
      Constructor11 obj1=new Constructor11();
      Constructor11 obj2=new Constructor11(10);
      Constructor11 obj3=new Constructor11(10,30);
   } 
}
class Constructor11
{
   Constructor11()
   {
      System.out.println("This is default constructor");
   }
   Constructor11(int a)
   {
     
     System.out.println("This is one parameterized constuctor");
   }
   Constructor11(int a,int b)
   {
      
      System.out.println("This is constructor having 2 arguments");
   }
}
