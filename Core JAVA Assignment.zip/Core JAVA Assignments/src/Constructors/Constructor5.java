/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Constructors;

/**
 *
 * @author mansi
 */

//we cannot invoke the constructor multiple times for an object after it is created.
class Constructors
{
  
   Constructors()
   {
      System.out.println("This is default constructor");
   }
}
public class Constructor5  extends Constructors{
    
  public static void main(String as[])
  {
     Constructors obj=new Constructor5();
     
  }
}
