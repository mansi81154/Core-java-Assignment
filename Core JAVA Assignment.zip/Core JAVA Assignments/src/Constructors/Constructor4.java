/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Constructors;

/**
 *
 * @author mansi
 */

//Constructor does not return any value so this program will run successfully but no output..
class ConstructorA
{
   int Constructor4(int a)
   {
      a=10;
     return a;
     
   }
    String ConstructorA(String var)
   {
     return "hello";
   }
}
public class Constructor4 extends ConstructorA{
    Constructor4()
  {
    super();
  }
  public static void main(String as[])
  {
    Constructor4 obj=new Constructor4();
  }
}
