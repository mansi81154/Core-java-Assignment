/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Operators;

/**
 *
 * @author mansi
 */
public class Operators5 {
    public void Logical(int num1,int num2,int num3)
   {
     if(num1<num2 && num1>num3)
      {
         int sum=num1+num2+num3;
         System.out.println("sum is:"+sum);
      }
     else
     {
       System.out.println("false condition..");
     }
     if(num1<num2 || num1==num2)
     {
        System.out.println("This is logical OR");
     }
     else
     {
        System.out.println("Condition false");
     }
     System.out.println("!(num1>num2)="+!(num1>num2));
     }
   public static void main(String as[])
   {
      Operators5 obj=new Operators5();
      obj.Logical(10,20,5);
   }
}
