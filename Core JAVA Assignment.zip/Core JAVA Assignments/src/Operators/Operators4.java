/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Operators;

/**
 *
 * @author mansi
 */
public class Operators4 {
    public void CheckEqual(int num1,int num2)
  {
     if(num1==num2)
     {
         System.out.println("both numbers are equal");
     }
     else 
     {
       System.out.println("numbers are not equal");
     }
  }
   public static void main(String as[])
   {
      Operators4 obj=new Operators4();
      obj.CheckEqual(10,20);
   }
}
