/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Operators;

/**
 *
 * @author mansi
 */
public class Operators6 {
    static int a=26,b=66;
  public static void main(String as[])
  {
    System.out.println(" Result of a >  b is = " + (a > b));
    System.out.println(" Result of a >=  b is = " + (a >= b));   	    System.out.println(" Result of a <  b is = " + (a < b));
    System.out.println(" Result of a <=  b is = " + (a <= b));
  }
}
