/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Operators;

/**
 *
 * @author mansi
 */
public class Operators2 {
    public void IncDec()
   {
     for(int i=1;i<=5;i++)
     {
     System.out.println("Value of i increasing:"+i);
     }
    System.out.println();
    for(int i=5;i>=1;i--)
     {
     System.out.println("Value of i decreasing:"+i);
     }
   }
   public static void main(String as[])
   {
      Operators2 obj=new Operators2();
      obj.IncDec();
   }
}
