/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Operators;

/**
 *
 * @author mansi
 */
public class Operators1 {
    public void Arith(int num1,int num2)
   {
     int sum=num1+num2;
     int sub=num1-num2;
     int multi=num1*num2;
     int div=num1/num2;
     System.out.println("Sum of two numbers is:"+sum);
     System.out.println("Subraction of two numbers is:"+sub);
     System.out.println("Multiplication of two numbers is:"+multi);
     System.out.println("Division of two numbers is:"+div);
   }
   public static void main(String as[])
   {
      Operators1 obj=new Operators1();
      obj.Arith(40,20);
   }
}
