/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Operators;

/**
 *
 * @author mansi
 */
public class Operators3 {
    public void equal(int num1,int num2,int num3)
  {
     if(num1==num2)
     {
       System.out.println("Both values are equal");
     }
     if(num1!=num3)
     {
       System.out.println("Both values are not equal");
     }
  }
  public static void main(String as[])
  {
     Operators3 obj=new Operators3();
     obj.equal(10,10,30);
  }
}
