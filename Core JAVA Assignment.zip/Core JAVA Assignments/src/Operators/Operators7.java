/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Operators;

/**
 *
 * @author mansi
 */
public class Operators7 {
     public void CheckSmall(int num1,int num2,int num3)
      {
      if(num1<num2&&num2<num3)
      {
         System.out.println("num1 is small");
      }
     else if(num2<num1&&num2<num3)
      {
         System.out.println("num2 is small");
      }
      else if(num3<num1&&num3<num2)
      {
         System.out.println("num3 is small");
      }
     }
     public void CheckLarge(int num1,int num2,int num3)
     {
        if(num1>num2 && num1>num3)
        {
          System.out.println("num1 is large");
        }
       else if(num2>num1 && num2>num3)
        {
          System.out.println("num2 is large");
        }
       else if(num3>num1 && num3>num2)
        {
          System.out.println("num3 is large");
        }
      }
     public static void main(String as[])
   { 
      Operators7 obj=new Operators7();
      obj.CheckSmall(20,40,10);
      obj.CheckLarge(20,40,10);
   }
}
