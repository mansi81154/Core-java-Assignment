/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package MethodOverloading;

/**
 *
 * @author mansi
 */
public class MethodOvr4 {
   public void Calci(int a,int b)
  {
     System.out.println(a*b);
  }
  public void Calci(String a,String b)
  {
    System.out.println(a+b);
  }
  public static void main(String as[])
  {
    MethodOvr4 obj=new MethodOvr4();
    obj.Calci(10,20);
    obj.Calci("Hello","World");
  } 
}
