/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package MethodOverloading;

/**
 *
 * @author mansi
 */
public class MethodOvr2 {
   public void Calci(int a)
   {
     
     System.out.println("Square is: "+(a*a));
   }
   public void Calci(String a,String b)
   {
     System.out.println(a+b);
   }
   public static void main(String as[])
   {
      MethodOvr2 obj=new MethodOvr2();
      obj.Calci(10);
      obj.Calci("hello","world");
    } 
}
