/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package MethodOverloading;

/**
 *
 * @author mansi
 */

// This will show an error when method signature is same
// and return type is different.


class Addition {
	// adding two integer value.
	public int add(int a, int b)
	{

		int sum = a + b;
		return sum;
	}

	// adding three integer value.
	/* Generate an error 
        public double add(int a, int b)
	{
		double sum = a + b + 0.0;
		return sum;
	}*/
}
public class MethodOvr5 {
    public static void main(String[] args)
	{       
                
		 
			Addition ob = new Addition();

			int sum1 = ob.add(1, 2);
			System.out.println(
				"sum of the two integer value :" + sum1);

			int sum2 = ob.add(1, 2);
			System.out.println(
				"sum of the three integer value :" + sum2);
		
	}
}
