/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package MethodOverloading;

/**
 *
 * @author mansi
 */
public class MethodOvr3 {
    public void Calci(int a,int b)
  {
     System.out.println("Sum is: "+(a+b));
  }
    /* This will show an error because signature is same of both methods..
  public void Calci(int a,int b)
  {
     System.out.println("Sub is: "+(a-b));
  }
  public static void main(String as[])
  {
     MethodOvr3 obj=new MethodOvr3();
     obj.Calci(10,20);
  }*/
}
